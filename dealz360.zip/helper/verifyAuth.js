const jwt = require('jsonwebtoken');


function verifyToken(req, res, next){
}

module.exports = verifyToken